use zomato;
select distinct Countryname From zomato.zomato_cleaned_final_corrected;
select Count(*) from zomato.zomato_cleaned_final_corrected;

#KPI 1 (Create Country Map Table)
CREATE TABLE Country_Map AS
SELECT DISTINCT CountryID, Countryname FROM zomato_cleaned_final_corrected;
 
select * from Country_Map;

#KPI 2 (Create Calendar Table)
CREATE TABLE Calendar AS
SELECT DISTINCT
    Datekey_Opening AS Datekey,
    YEAR(Datekey_Opening) AS Year,
    MONTH(Datekey_Opening) AS Monthno,
    DATE_FORMAT(Datekey_Opening, '%M') AS Monthfullname,
    CASE 
        WHEN MONTH(Datekey_Opening) BETWEEN 1 AND 3 THEN 'Q1'
        WHEN MONTH(Datekey_Opening) BETWEEN 4 AND 6 THEN 'Q2'
        WHEN MONTH(Datekey_Opening) BETWEEN 7 AND 9 THEN 'Q3'
        ELSE 'Q4' 
    END AS Quarter,
    DATE_FORMAT(Datekey_Opening, '%Y-%m') AS YearMonth,
    WEEKDAY(Datekey_Opening) + 1 AS Weekdayno,
    DAYNAME(Datekey_Opening) AS Weekdayname,
    CASE 
        WHEN MONTH(Datekey_Opening) = 4 THEN 'FM1'
        WHEN MONTH(Datekey_Opening) = 5 THEN 'FM2'
        WHEN MONTH(Datekey_Opening) = 6 THEN 'FM3'
        WHEN MONTH(Datekey_Opening) = 7 THEN 'FM4'
        WHEN MONTH(Datekey_Opening) = 8 THEN 'FM5'
        WHEN MONTH(Datekey_Opening) = 9 THEN 'FM6'
        WHEN MONTH(Datekey_Opening) = 10 THEN 'FM7'
        WHEN MONTH(Datekey_Opening) = 11 THEN 'FM8'
        WHEN MONTH(Datekey_Opening) = 12 THEN 'FM9'
        WHEN MONTH(Datekey_Opening) = 1 THEN 'FM10'
        WHEN MONTH(Datekey_Opening) = 2 THEN 'FM11'
        ELSE 'FM12' 
    END AS FinancialMonth,
    CASE 
        WHEN MONTH(Datekey_Opening) BETWEEN 4 AND 6 THEN 'FQ1'
        WHEN MONTH(Datekey_Opening) BETWEEN 7 AND 9 THEN 'FQ2'
        WHEN MONTH(Datekey_Opening) BETWEEN 10 AND 12 THEN 'FQ3'
        ELSE 'FQ4' 
    END AS FinancialQuarter
FROM zomato.zomato_cleaned_final_corrected;

SELECT * FROM Calendar LIMIT 100;

SELECT * FROM Calendar WHERE Year = '2013';

SELECT * FROM Calendar WHERE Monthfullname = 'January';

SELECT FinancialQuarter, COUNT(*) AS Total_Days FROM Calendar GROUP BY FinancialQuarter;


#KPI3 (Count of Restaurants by City and Country)
SELECT Countryname, City, COUNT(*) AS Restaurant_Count 
FROM zomato_cleaned_final_corrected 
GROUP BY Countryname, City;

#KPI 4(Number of Restaurants Opened by Year, Quarter, Month)
SELECT Year, Quarter, Monthfullname, COUNT(*) AS Opened_Restaurants 
FROM Calendar
GROUP BY Year, Quarter, Monthfullname;

#KPI 5(Count of Restaurants by Average Ratings)
SELECT Rating, COUNT(*) AS Restaurant_Count 
FROM zomato_cleaned_final_corrected
GROUP BY Rating;


#KPI6 (Bucketing Restaurants Based on Average Cost for Two)
SELECT 
    CASE 
        WHEN Average_Cost_for_two <= 500 THEN 'Low (0-500)'
        WHEN Average_Cost_for_two BETWEEN 501 AND 1000 THEN 'Medium (501-1000)'
        WHEN Average_Cost_for_two BETWEEN 1001 AND 2000 THEN 'High (1001-2000)'
        ELSE 'Luxury (2001+)' 
    END AS Price_Bucket,
    COUNT(*) AS Restaurant_Count
FROM zomato_cleaned_final_corrected
GROUP BY Price_Bucket;


#KPI 7 (Percentage of Restaurants with Table Booking)
SELECT 
    (SUM(CASE WHEN Has_Table_booking = '1' THEN 1 ELSE 0 END) * 100.0) / COUNT(*) AS Table_Booking_Percentage
FROM zomato_cleaned_final_corrected;

#KPI 8 (Percentage of Restaurants with Online Delivery)
SELECT 
    (SUM(CASE WHEN Has_Online_delivery = '1' THEN 1 ELSE 0 END) * 100.0) / COUNT(*) AS Online_Delivery_Percentage
FROM zomato_cleaned_final_corrected;

#KPI 9(Example Query: Count of Restaurants by Cuisines)
SELECT Cuisines, COUNT(*) AS Restaurant_Count 
FROM zomato_cleaned_final_corrected 
GROUP BY Cuisines 
ORDER BY Restaurant_Count DESC;




















